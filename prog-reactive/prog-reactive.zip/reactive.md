# Progrmmation réactive

## C'est quoi ?
- flux asynchrone
- évènements ordonnées dans le temps
- écoute / souscription
- Pattern Obverser / observable
- Notation
 - Création
 - Nouvelle valeur
 - Erreur
 - Fin
 - -a--b--c--X----|-->
- Immutabilité
- Opérations
 - map
 - filter
 - scan (reduce)

## Pourquoi ?

- Code concis
- dépendances explicites
- Découplage des flux

# Exemple : suggestions ded twitter

- 

